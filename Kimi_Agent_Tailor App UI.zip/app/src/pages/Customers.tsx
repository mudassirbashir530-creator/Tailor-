import { useState, useRef } from 'react';
import { useAuth } from '@/contexts/AuthContext';
import { useCustomers, useStorage } from '@/hooks';
import {
  Users,
  Search,
  Plus,
  Phone,
  Mail,
  MapPin,
  Ruler,
  Camera,
  X,
  ChevronDown,
  ChevronUp,
  Loader2,
  Trash2,
  Edit2
} from 'lucide-react';
import type { Customer, Measurements } from '@/types';

interface CustomersProps {
  onNavigate: (page: string) => void;
}

const measurementFields = [
  { key: 'chest', label: 'Chest' },
  { key: 'waist', label: 'Waist' },
  { key: 'hips', label: 'Hips' },
  { key: 'shoulder', label: 'Shoulder' },
  { key: 'sleeve', label: 'Sleeve' },
  { key: 'length', label: 'Length' },
  { key: 'neck', label: 'Neck' },
  { key: 'armhole', label: 'Armhole' },
  { key: 'wrist', label: 'Wrist' },
  { key: 'thigh', label: 'Thigh' },
  { key: 'knee', label: 'Knee' },
  { key: 'ankle', label: 'Ankle' }
];

export default function Customers({ onNavigate }: CustomersProps) {
  const { user } = useAuth();
  const { customers, loading, addCustomer, updateCustomer, deleteCustomer } = useCustomers(user?.uid);
  const { uploadImage, uploading, progress } = useStorage();
  
  const [showAddModal, setShowAddModal] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [expandedCustomer, setExpandedCustomer] = useState<string | null>(null);
  const [editingCustomer, setEditingCustomer] = useState<Customer | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  // Form state
  const [formData, setFormData] = useState({
    name: '',
    phone: '',
    email: '',
    address: '',
    notes: '',
    measurements: {} as Measurements,
    referenceImage: ''
  });
  const [imageFile, setImageFile] = useState<File | null>(null);
  const [imagePreview, setImagePreview] = useState('');
  const [submitting, setSubmitting] = useState(false);

  const filteredCustomers = customers.filter(c =>
    c.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
    c.phone.includes(searchQuery)
  );

  const handleImageSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      setImageFile(file);
      const reader = new FileReader();
      reader.onloadend = () => setImagePreview(reader.result as string);
      reader.readAsDataURL(file);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user) return;

    setSubmitting(true);
    try {
      let imageUrl = formData.referenceImage;
      
      if (imageFile) {
        imageUrl = await uploadImage(imageFile, 'customers', user.uid);
      }

      const customerData = {
        shopId: user.uid,
        name: formData.name,
        phone: formData.phone,
        email: formData.email,
        address: formData.address,
        measurements: formData.measurements,
        referenceImage: imageUrl,
        notes: formData.notes
      };

      if (editingCustomer) {
        await updateCustomer(editingCustomer.id, customerData);
      } else {
        await addCustomer(customerData);
      }

      resetForm();
      setShowAddModal(false);
    } catch (error) {
      console.error('Error saving customer:', error);
    } finally {
      setSubmitting(false);
    }
  };

  const resetForm = () => {
    setFormData({
      name: '',
      phone: '',
      email: '',
      address: '',
      notes: '',
      measurements: {},
      referenceImage: ''
    });
    setImageFile(null);
    setImagePreview('');
    setEditingCustomer(null);
  };

  const handleEdit = (customer: Customer) => {
    setEditingCustomer(customer);
    setFormData({
      name: customer.name,
      phone: customer.phone,
      email: customer.email || '',
      address: customer.address || '',
      notes: customer.notes || '',
      measurements: customer.measurements || {},
      referenceImage: customer.referenceImage || ''
    });
    setImagePreview(customer.referenceImage || '');
    setShowAddModal(true);
  };

  const handleDelete = async (customerId: string) => {
    if (confirm('Are you sure you want to delete this customer?')) {
      await deleteCustomer(customerId);
    }
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h1 className="font-heading font-bold text-2xl lg:text-3xl text-text-primary">
            Customers
          </h1>
          <p className="text-text-secondary mt-1">
            Manage your client profiles and measurements
          </p>
        </div>
        <button
          onClick={() => {
            resetForm();
            setShowAddModal(true);
          }}
          className="btn-primary flex items-center justify-center gap-2"
        >
          <Plus className="w-5 h-5" />
          Add Customer
        </button>
      </div>

      {/* Search */}
      <div className="relative">
        <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-text-secondary" />
        <input
          type="text"
          placeholder="Search customers by name or phone..."
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          className="w-full pl-12 pr-4 py-3 rounded-xl bg-white/80 border border-slate focus:border-pink focus:ring-2 focus:ring-pink/20 outline-none transition-all"
        />
      </div>

      {/* Customers List */}
      {loading ? (
        <div className="flex justify-center py-12">
          <Loader2 className="w-8 h-8 animate-spin text-pink" />
        </div>
      ) : filteredCustomers.length === 0 ? (
        <div className="glass-card p-12 text-center">
          <Users className="w-16 h-16 mx-auto mb-4 text-text-secondary opacity-30" />
          <h3 className="font-heading font-semibold text-lg text-text-primary mb-2">
            No customers yet
          </h3>
          <p className="text-text-secondary mb-4">
            Add your first customer to get started
          </p>
          <button
            onClick={() => setShowAddModal(true)}
            className="btn-primary"
          >
            Add Customer
          </button>
        </div>
      ) : (
        <div className="space-y-3">
          {filteredCustomers.map((customer) => (
            <div key={customer.id} className="glass-card overflow-hidden">
              <button
                onClick={() => setExpandedCustomer(
                  expandedCustomer === customer.id ? null : customer.id
                )}
                className="w-full p-4 flex items-center gap-4 hover:bg-white/40 transition-colors"
              >
                <div className="w-12 h-12 rounded-xl bg-pink/20 flex items-center justify-center flex-shrink-0">
                  {customer.referenceImage ? (
                    <img
                      src={customer.referenceImage}
                      alt={customer.name}
                      className="w-full h-full object-cover rounded-xl"
                    />
                  ) : (
                    <Users className="w-6 h-6 text-pink" />
                  )}
                </div>
                <div className="flex-1 text-left">
                  <h3 className="font-medium text-text-primary">{customer.name}</h3>
                  <p className="text-sm text-text-secondary">{customer.phone}</p>
                </div>
                {expandedCustomer === customer.id ? (
                  <ChevronUp className="w-5 h-5 text-text-secondary" />
                ) : (
                  <ChevronDown className="w-5 h-5 text-text-secondary" />
                )}
              </button>

              {expandedCustomer === customer.id && (
                <div className="px-4 pb-4 border-t border-slate/50">
                  <div className="pt-4 grid sm:grid-cols-2 gap-4">
                    {/* Contact Info */}
                    <div className="space-y-2">
                      <h4 className="font-medium text-text-primary flex items-center gap-2">
                        <Phone className="w-4 h-4 text-pink" />
                        Contact
                      </h4>
                      <p className="text-sm text-text-secondary pl-6">{customer.phone}</p>
                      {customer.email && (
                        <p className="text-sm text-text-secondary pl-6 flex items-center gap-2">
                          <Mail className="w-4 h-4" />
                          {customer.email}
                        </p>
                      )}
                      {customer.address && (
                        <p className="text-sm text-text-secondary pl-6 flex items-center gap-2">
                          <MapPin className="w-4 h-4" />
                          {customer.address}
                        </p>
                      )}
                    </div>

                    {/* Measurements */}
                    <div>
                      <h4 className="font-medium text-text-primary flex items-center gap-2 mb-2">
                        <Ruler className="w-4 h-4 text-pink" />
                        Measurements
                      </h4>
                      <div className="grid grid-cols-3 gap-2">
                        {measurementFields.slice(0, 6).map((field) => {
                          const value = customer.measurements?.[field.key];
                          return value ? (
                            <div key={field.key} className="glass-card-sm px-2 py-1.5 text-center">
                              <p className="text-xs text-text-secondary">{field.label}</p>
                              <p className="font-medium text-text-primary">{value}&quot;</p>
                            </div>
                          ) : null;
                        })}
                      </div>
                      {Object.keys(customer.measurements || {}).length > 6 && (
                        <p className="text-xs text-text-secondary mt-2">
                          +{Object.keys(customer.measurements || {}).length - 6} more measurements
                        </p>
                      )}
                    </div>
                  </div>

                  {/* Notes */}
                  {customer.notes && (
                    <div className="mt-4 p-3 rounded-xl bg-amber-50">
                      <p className="text-sm text-amber-800">{customer.notes}</p>
                    </div>
                  )}

                  {/* Actions */}
                  <div className="mt-4 flex gap-2">
                    <button
                      onClick={() => handleEdit(customer)}
                      className="flex items-center gap-2 px-4 py-2 rounded-xl bg-blue-50 text-blue-600 hover:bg-blue-100 transition-colors"
                    >
                      <Edit2 className="w-4 h-4" />
                      Edit
                    </button>
                    <button
                      onClick={() => handleDelete(customer.id)}
                      className="flex items-center gap-2 px-4 py-2 rounded-xl bg-red-50 text-red-600 hover:bg-red-100 transition-colors"
                    >
                      <Trash2 className="w-4 h-4" />
                      Delete
                    </button>
                    <button
                      onClick={() => onNavigate('orders')}
                      className="flex items-center gap-2 px-4 py-2 rounded-xl bg-pink/10 text-pink-dark hover:bg-pink/20 transition-colors ml-auto"
                    >
                      <Plus className="w-4 h-4" />
                      New Order
                    </button>
                  </div>
                </div>
              )}
            </div>
          ))}
        </div>
      )}

      {/* Add/Edit Modal */}
      {showAddModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50 backdrop-blur-sm">
          <div className="glass-card w-full max-w-2xl max-h-[90vh] overflow-auto">
            <div className="sticky top-0 bg-white/90 backdrop-blur-xl border-b border-slate p-4 flex items-center justify-between">
              <h2 className="font-heading font-semibold text-xl text-text-primary">
                {editingCustomer ? 'Edit Customer' : 'Add New Customer'}
              </h2>
              <button
                onClick={() => {
                  setShowAddModal(false);
                  resetForm();
                }}
                className="w-10 h-10 rounded-xl hover:bg-slate flex items-center justify-center"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSubmit} className="p-4 space-y-4">
              {/* Image Upload */}
              <div>
                <label className="block text-sm font-medium text-text-primary mb-2">
                  Reference Photo
                </label>
                <div className="flex items-center gap-4">
                  <div className="w-24 h-24 rounded-xl bg-slate flex items-center justify-center overflow-hidden">
                    {imagePreview ? (
                      <img
                        src={imagePreview}
                        alt="Preview"
                        className="w-full h-full object-cover"
                      />
                    ) : (
                      <Camera className="w-8 h-8 text-text-secondary" />
                    )}
                  </div>
                  <div>
                    <input
                      ref={fileInputRef}
                      type="file"
                      accept="image/*"
                      onChange={handleImageSelect}
                      className="hidden"
                    />
                    <button
                      type="button"
                      onClick={() => fileInputRef.current?.click()}
                      className="btn-secondary text-sm"
                    >
                      {imagePreview ? 'Change Photo' : 'Upload Photo'}
                    </button>
                    {uploading && (
                      <p className="text-sm text-text-secondary mt-2">
                        Uploading... {progress}%
                      </p>
                    )}
                  </div>
                </div>
              </div>

              {/* Basic Info */}
              <div className="grid sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-text-primary mb-1.5">
                    Name *
                  </label>
                  <input
                    type="text"
                    value={formData.name}
                    onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                    placeholder="Customer name"
                    className="w-full px-4 py-3 rounded-xl bg-white/80 border border-slate focus:border-pink focus:ring-2 focus:ring-pink/20 outline-none transition-all"
                    required
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-text-primary mb-1.5">
                    Phone *
                  </label>
                  <input
                    type="tel"
                    value={formData.phone}
                    onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                    placeholder="Phone number"
                    className="w-full px-4 py-3 rounded-xl bg-white/80 border border-slate focus:border-pink focus:ring-2 focus:ring-pink/20 outline-none transition-all"
                    required
                  />
                </div>
              </div>

              <div className="grid sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-text-primary mb-1.5">
                    Email
                  </label>
                  <input
                    type="email"
                    value={formData.email}
                    onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                    placeholder="Email address"
                    className="w-full px-4 py-3 rounded-xl bg-white/80 border border-slate focus:border-pink focus:ring-2 focus:ring-pink/20 outline-none transition-all"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-text-primary mb-1.5">
                    Address
                  </label>
                  <input
                    type="text"
                    value={formData.address}
                    onChange={(e) => setFormData({ ...formData, address: e.target.value })}
                    placeholder="Customer address"
                    className="w-full px-4 py-3 rounded-xl bg-white/80 border border-slate focus:border-pink focus:ring-2 focus:ring-pink/20 outline-none transition-all"
                  />
                </div>
              </div>

              {/* Measurements */}
              <div>
                <label className="block text-sm font-medium text-text-primary mb-2">
                  Measurements (inches)
                </label>
                <div className="grid grid-cols-3 sm:grid-cols-4 gap-3">
                  {measurementFields.map((field) => (
                    <div key={field.key}>
                      <label className="text-xs text-text-secondary">{field.label}</label>
                      <input
                        type="number"
                        step="0.1"
                        value={formData.measurements[field.key] || ''}
                        onChange={(e) => setFormData({
                          ...formData,
                          measurements: {
                            ...formData.measurements,
                            [field.key]: parseFloat(e.target.value) || undefined
                          }
                        })}
                        placeholder="0"
                        className="w-full px-3 py-2 rounded-lg bg-white/80 border border-slate focus:border-pink focus:ring-2 focus:ring-pink/20 outline-none transition-all text-sm"
                      />
                    </div>
                  ))}
                </div>
              </div>

              {/* Notes */}
              <div>
                <label className="block text-sm font-medium text-text-primary mb-1.5">
                  Notes
                </label>
                <textarea
                  value={formData.notes}
                  onChange={(e) => setFormData({ ...formData, notes: e.target.value })}
                  placeholder="Any additional notes..."
                  rows={3}
                  className="w-full px-4 py-3 rounded-xl bg-white/80 border border-slate focus:border-pink focus:ring-2 focus:ring-pink/20 outline-none transition-all resize-none"
                />
              </div>

              {/* Submit */}
              <div className="sticky bottom-0 bg-white/90 backdrop-blur-xl border-t border-slate pt-4 flex gap-3">
                <button
                  type="button"
                  onClick={() => {
                    setShowAddModal(false);
                    resetForm();
                  }}
                  className="flex-1 btn-secondary"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={submitting}
                  className="flex-1 btn-primary flex items-center justify-center gap-2"
                >
                  {submitting && <Loader2 className="w-5 h-5 animate-spin" />}
                  {editingCustomer ? 'Update Customer' : 'Add Customer'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
