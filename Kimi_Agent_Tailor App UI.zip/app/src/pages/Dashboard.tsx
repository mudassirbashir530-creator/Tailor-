import { useAuth } from '@/contexts/AuthContext';
import { useDashboardStats } from '@/hooks/useFirestore';
import {
  Users,
  ClipboardList,
  CheckCircle2,
  AlertCircle,
  IndianRupee,
  TrendingUp,
  ArrowRight
} from 'lucide-react';

interface DashboardProps {
  onNavigate: (page: string) => void;
}

export default function Dashboard({ onNavigate }: DashboardProps) {
  const { user, shop } = useAuth();
  const { stats, loading } = useDashboardStats(user?.uid);

  const statCards = [
    {
      title: 'Total Customers',
      value: stats.totalCustomers,
      icon: Users,
      color: 'bg-blue-500',
      lightColor: 'bg-blue-50',
      onClick: () => onNavigate('customers')
    },
    {
      title: 'Active Orders',
      value: stats.activeOrders,
      icon: ClipboardList,
      color: 'bg-pink',
      lightColor: 'bg-pink/10',
      onClick: () => onNavigate('orders')
    },
    {
      title: 'Completed Orders',
      value: stats.completedOrders,
      icon: CheckCircle2,
      color: 'bg-green-500',
      lightColor: 'bg-green-50',
      onClick: () => onNavigate('orders')
    },
    {
      title: 'Pending Payments',
      value: stats.pendingPayments,
      icon: AlertCircle,
      color: 'bg-amber-500',
      lightColor: 'bg-amber-50',
      onClick: () => onNavigate('orders')
    }
  ];

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h1 className="font-heading font-bold text-2xl lg:text-3xl text-text-primary">
            Dashboard
          </h1>
          <p className="text-text-secondary mt-1">
            Welcome back, {shop?.name || 'Your Shop'}
          </p>
        </div>
        <div className="glass-card-sm px-4 py-2 flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-green-100 flex items-center justify-center">
            <IndianRupee className="w-5 h-5 text-green-600" />
          </div>
          <div>
            <p className="text-xs text-text-secondary">Total Revenue</p>
            <p className="font-heading font-bold text-lg text-text-primary">
              ₹{stats.totalRevenue.toLocaleString()}
            </p>
          </div>
        </div>
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        {statCards.map((card, index) => (
          <button
            key={index}
            onClick={card.onClick}
            className="glass-card p-4 lg:p-5 text-left hover:shadow-glass transition-all duration-300 group"
          >
            <div className="flex items-start justify-between mb-3">
              <div className={`w-10 h-10 lg:w-12 lg:h-12 rounded-xl ${card.lightColor} flex items-center justify-center`}>
                <card.icon className={`w-5 h-5 lg:w-6 lg:h-6 ${card.color.replace('bg-', 'text-')}`} />
              </div>
              <ArrowRight className="w-5 h-5 text-text-secondary opacity-0 group-hover:opacity-100 transition-opacity" />
            </div>
            <p className="text-text-secondary text-sm">{card.title}</p>
            <p className="font-heading font-bold text-2xl lg:text-3xl text-text-primary mt-1">
              {loading ? '-' : card.value}
            </p>
          </button>
        ))}
      </div>

      {/* Quick Actions */}
      <div className="glass-card p-6">
        <h2 className="font-heading font-semibold text-lg text-text-primary mb-4">
          Quick Actions
        </h2>
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-3">
          <button
            onClick={() => onNavigate('customers')}
            className="flex items-center gap-3 p-4 rounded-xl bg-pink/10 hover:bg-pink/20 transition-colors text-left"
          >
            <div className="w-10 h-10 rounded-xl bg-pink flex items-center justify-center">
              <Users className="w-5 h-5 text-white" />
            </div>
            <div>
              <p className="font-medium text-text-primary">Add Customer</p>
              <p className="text-sm text-text-secondary">New client profile</p>
            </div>
          </button>

          <button
            onClick={() => onNavigate('orders')}
            className="flex items-center gap-3 p-4 rounded-xl bg-blue-50 hover:bg-blue-100 transition-colors text-left"
          >
            <div className="w-10 h-10 rounded-xl bg-blue-500 flex items-center justify-center">
              <ClipboardList className="w-5 h-5 text-white" />
            </div>
            <div>
              <p className="font-medium text-text-primary">Create Order</p>
              <p className="text-sm text-text-secondary">New order entry</p>
            </div>
          </button>

          <button
            onClick={() => onNavigate('settings')}
            className="flex items-center gap-3 p-4 rounded-xl bg-amber-50 hover:bg-amber-100 transition-colors text-left"
          >
            <div className="w-10 h-10 rounded-xl bg-amber-500 flex items-center justify-center">
              <TrendingUp className="w-5 h-5 text-white" />
            </div>
            <div>
              <p className="font-medium text-text-primary">Shop Settings</p>
              <p className="text-sm text-text-secondary">Update profile</p>
            </div>
          </button>
        </div>
      </div>

      {/* Recent Activity Placeholder */}
      <div className="glass-card p-6">
        <div className="flex items-center justify-between mb-4">
          <h2 className="font-heading font-semibold text-lg text-text-primary">
            Recent Activity
          </h2>
          <button 
            onClick={() => onNavigate('orders')}
            className="text-pink-dark text-sm font-medium hover:underline"
          >
            View all
          </button>
        </div>
        <div className="text-center py-8 text-text-secondary">
          <ClipboardList className="w-12 h-12 mx-auto mb-3 opacity-30" />
          <p>Your recent orders will appear here</p>
          <button
            onClick={() => onNavigate('orders')}
            className="btn-primary mt-4"
          >
            Create your first order
          </button>
        </div>
      </div>
    </div>
  );
}
