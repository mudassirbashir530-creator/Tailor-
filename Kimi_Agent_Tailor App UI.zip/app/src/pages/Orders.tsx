import { useState, useRef } from 'react';
import { useAuth } from '@/contexts/AuthContext';
import { useOrders, useCustomers, useStorage } from '@/hooks';
import {
  ClipboardList,
  Plus,
  Search,
  Calendar,
  Camera,
  X,
  Loader2,
  IndianRupee,
  CheckCircle2,
  Clock,
  Truck,
  Trash2,
  Edit2,
  FileText
} from 'lucide-react';
import type { Order } from '@/types';

interface OrdersProps {
  onNavigate: (page: string) => void;
}

const orderStatuses = [
  { value: 'pending', label: 'Pending', color: 'bg-amber-500', icon: Clock },
  { value: 'in-progress', label: 'In Progress', color: 'bg-blue-500', icon: ClipboardList },
  { value: 'completed', label: 'Completed', color: 'bg-green-500', icon: CheckCircle2 },
  { value: 'delivered', label: 'Delivered', color: 'bg-purple-500', icon: Truck }
];

const paymentStatuses = [
  { value: 'pending', label: 'Pending', color: 'text-amber-600', bgColor: 'bg-amber-50' },
  { value: 'partial', label: 'Partial', color: 'text-blue-600', bgColor: 'bg-blue-50' },
  { value: 'paid', label: 'Paid', color: 'text-green-600', bgColor: 'bg-green-50' }
];

export default function Orders({ onNavigate }: OrdersProps) {
  const { user } = useAuth();
  const { orders, loading, addOrder, updateOrder, deleteOrder } = useOrders(user?.uid);
  const { customers } = useCustomers(user?.uid);
  const { uploadImage, uploading, progress } = useStorage();

  const [showAddModal, setShowAddModal] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [filterStatus, setFilterStatus] = useState<string>('all');
  const [editingOrder, setEditingOrder] = useState<Order | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  // Form state
  const [formData, setFormData] = useState({
    customerId: '',
    customerName: '',
    suitType: '',
    suitDetails: '',
    deliveryDate: '',
    status: 'pending' as Order['status'],
    paymentStatus: 'pending' as Order['paymentStatus'],
    totalAmount: 0,
    paidAmount: 0,
    notes: '',
    sampleImage: ''
  });
  const [imageFile, setImageFile] = useState<File | null>(null);
  const [imagePreview, setImagePreview] = useState('');
  const [submitting, setSubmitting] = useState(false);

  const filteredOrders = orders.filter(order => {
    const matchesSearch = order.customerName.toLowerCase().includes(searchQuery.toLowerCase()) ||
                         order.suitType.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesStatus = filterStatus === 'all' || order.status === filterStatus;
    return matchesSearch && matchesStatus;
  });

  const handleImageSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      setImageFile(file);
      const reader = new FileReader();
      reader.onloadend = () => setImagePreview(reader.result as string);
      reader.readAsDataURL(file);
    }
  };

  const handleCustomerSelect = (customerId: string) => {
    const customer = customers.find(c => c.id === customerId);
    if (customer) {
      setFormData({
        ...formData,
        customerId,
        customerName: customer.name
      });
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user || !formData.customerId) return;

    setSubmitting(true);
    try {
      let imageUrl = formData.sampleImage;
      
      if (imageFile) {
        imageUrl = await uploadImage(imageFile, 'orders', user.uid);
      }

      // Calculate image expiry date (14 days after delivery)
      const deliveryDate = new Date(formData.deliveryDate);
      const imageExpiryDate = new Date(deliveryDate);
      imageExpiryDate.setDate(imageExpiryDate.getDate() + 14);

      const orderData = {
        shopId: user.uid,
        customerId: formData.customerId,
        customerName: formData.customerName,
        suitType: formData.suitType,
        suitDetails: formData.suitDetails,
        sampleImage: imageUrl,
        deliveryDate,
        status: formData.status,
        paymentStatus: formData.paymentStatus,
        totalAmount: formData.totalAmount,
        paidAmount: formData.paidAmount,
        notes: formData.notes,
        imageExpiryDate
      };

      if (editingOrder) {
        await updateOrder(editingOrder.id, orderData);
      } else {
        await addOrder(orderData);
      }

      resetForm();
      setShowAddModal(false);
    } catch (error) {
      console.error('Error saving order:', error);
    } finally {
      setSubmitting(false);
    }
  };

  const resetForm = () => {
    setFormData({
      customerId: '',
      customerName: '',
      suitType: '',
      suitDetails: '',
      deliveryDate: '',
      status: 'pending',
      paymentStatus: 'pending',
      totalAmount: 0,
      paidAmount: 0,
      notes: '',
      sampleImage: ''
    });
    setImageFile(null);
    setImagePreview('');
    setEditingOrder(null);
  };

  const handleEdit = (order: Order) => {
    setEditingOrder(order);
    setFormData({
      customerId: order.customerId,
      customerName: order.customerName,
      suitType: order.suitType,
      suitDetails: order.suitDetails,
      deliveryDate: order.deliveryDate.toISOString().split('T')[0],
      status: order.status,
      paymentStatus: order.paymentStatus,
      totalAmount: order.totalAmount,
      paidAmount: order.paidAmount,
      notes: order.notes || '',
      sampleImage: order.sampleImage || ''
    });
    setImagePreview(order.sampleImage || '');
    setShowAddModal(true);
  };

  const handleDelete = async (orderId: string) => {
    if (confirm('Are you sure you want to delete this order?')) {
      await deleteOrder(orderId);
    }
  };

  const getStatusBadge = (status: string) => {
    const statusConfig = orderStatuses.find(s => s.value === status);
    if (!statusConfig) return null;
    const Icon = statusConfig.icon;
    return (
      <span className={`inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-medium ${statusConfig.color.replace('bg-', 'bg-').replace('500', '100')} ${statusConfig.color.replace('bg-', 'text-')}`}>
        <Icon className="w-3.5 h-3.5" />
        {statusConfig.label}
      </span>
    );
  };

  const getPaymentBadge = (status: string) => {
    const statusConfig = paymentStatuses.find(s => s.value === status);
    if (!statusConfig) return null;
    return (
      <span className={`inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-medium ${statusConfig.bgColor} ${statusConfig.color}`}>
        <IndianRupee className="w-3.5 h-3.5" />
        {statusConfig.label}
      </span>
    );
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h1 className="font-heading font-bold text-2xl lg:text-3xl text-text-primary">
            Orders
          </h1>
          <p className="text-text-secondary mt-1">
            Manage orders and track progress
          </p>
        </div>
        <button
          onClick={() => {
            resetForm();
            setShowAddModal(true);
          }}
          className="btn-primary flex items-center justify-center gap-2"
        >
          <Plus className="w-5 h-5" />
          New Order
        </button>
      </div>

      {/* Filters */}
      <div className="flex flex-col sm:flex-row gap-3">
        <div className="relative flex-1">
          <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-text-secondary" />
          <input
            type="text"
            placeholder="Search orders..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full pl-12 pr-4 py-3 rounded-xl bg-white/80 border border-slate focus:border-pink focus:ring-2 focus:ring-pink/20 outline-none transition-all"
          />
        </div>
        <select
          value={filterStatus}
          onChange={(e) => setFilterStatus(e.target.value)}
          className="px-4 py-3 rounded-xl bg-white/80 border border-slate focus:border-pink focus:ring-2 focus:ring-pink/20 outline-none transition-all"
        >
          <option value="all">All Status</option>
          {orderStatuses.map(s => (
            <option key={s.value} value={s.value}>{s.label}</option>
          ))}
        </select>
      </div>

      {/* Orders List */}
      {loading ? (
        <div className="flex justify-center py-12">
          <Loader2 className="w-8 h-8 animate-spin text-pink" />
        </div>
      ) : filteredOrders.length === 0 ? (
        <div className="glass-card p-12 text-center">
          <ClipboardList className="w-16 h-16 mx-auto mb-4 text-text-secondary opacity-30" />
          <h3 className="font-heading font-semibold text-lg text-text-primary mb-2">
            No orders yet
          </h3>
          <p className="text-text-secondary mb-4">
            Create your first order to get started
          </p>
          <button
            onClick={() => setShowAddModal(true)}
            className="btn-primary"
          >
            Create Order
          </button>
        </div>
      ) : (
        <div className="grid gap-3">
          {filteredOrders.map((order) => (
            <div key={order.id} className="glass-card p-4">
              <div className="flex flex-col sm:flex-row sm:items-center gap-4">
                {/* Image */}
                <div className="w-16 h-16 rounded-xl bg-slate flex-shrink-0 overflow-hidden">
                  {order.sampleImage ? (
                    <img
                      src={order.sampleImage}
                      alt={order.suitType}
                      className="w-full h-full object-cover"
                    />
                  ) : (
                    <div className="w-full h-full flex items-center justify-center">
                      <ClipboardList className="w-6 h-6 text-text-secondary" />
                    </div>
                  )}
                </div>

                {/* Info */}
                <div className="flex-1 min-w-0">
                  <div className="flex flex-wrap items-center gap-2 mb-1">
                    <h3 className="font-medium text-text-primary truncate">{order.customerName}</h3>
                    {getStatusBadge(order.status)}
                    {getPaymentBadge(order.paymentStatus)}
                  </div>
                  <p className="text-sm text-text-secondary">{order.suitType}</p>
                  <div className="flex flex-wrap items-center gap-3 mt-2 text-xs text-text-secondary">
                    <span className="flex items-center gap-1">
                      <Calendar className="w-3.5 h-3.5" />
                      Due: {order.deliveryDate.toLocaleDateString()}
                    </span>
                    <span className="flex items-center gap-1">
                      <IndianRupee className="w-3.5 h-3.5" />
                      ₹{order.totalAmount.toLocaleString()}
                      {order.paymentStatus !== 'paid' && (
                        <span className="text-amber-600">
                          (₹{(order.totalAmount - order.paidAmount).toLocaleString()} pending)
                        </span>
                      )}
                    </span>
                  </div>
                </div>

                {/* Actions */}
                <div className="flex items-center gap-2">
                  {order.paymentStatus === 'paid' && (
                    <button
                      onClick={() => onNavigate('invoices')}
                      className="w-10 h-10 rounded-xl bg-green-50 text-green-600 hover:bg-green-100 flex items-center justify-center"
                      title="View Invoice"
                    >
                      <FileText className="w-5 h-5" />
                    </button>
                  )}
                  <button
                    onClick={() => handleEdit(order)}
                    className="w-10 h-10 rounded-xl bg-blue-50 text-blue-600 hover:bg-blue-100 flex items-center justify-center"
                  >
                    <Edit2 className="w-5 h-5" />
                  </button>
                  <button
                    onClick={() => handleDelete(order.id)}
                    className="w-10 h-10 rounded-xl bg-red-50 text-red-600 hover:bg-red-100 flex items-center justify-center"
                  >
                    <Trash2 className="w-5 h-5" />
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Add/Edit Modal */}
      {showAddModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50 backdrop-blur-sm">
          <div className="glass-card w-full max-w-2xl max-h-[90vh] overflow-auto">
            <div className="sticky top-0 bg-white/90 backdrop-blur-xl border-b border-slate p-4 flex items-center justify-between">
              <h2 className="font-heading font-semibold text-xl text-text-primary">
                {editingOrder ? 'Edit Order' : 'Create New Order'}
              </h2>
              <button
                onClick={() => {
                  setShowAddModal(false);
                  resetForm();
                }}
                className="w-10 h-10 rounded-xl hover:bg-slate flex items-center justify-center"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSubmit} className="p-4 space-y-4">
              {/* Customer Select */}
              <div>
                <label className="block text-sm font-medium text-text-primary mb-1.5">
                  Customer *
                </label>
                <select
                  value={formData.customerId}
                  onChange={(e) => handleCustomerSelect(e.target.value)}
                  className="w-full px-4 py-3 rounded-xl bg-white/80 border border-slate focus:border-pink focus:ring-2 focus:ring-pink/20 outline-none transition-all"
                  required
                >
                  <option value="">Select a customer</option>
                  {customers.map(customer => (
                    <option key={customer.id} value={customer.id}>
                      {customer.name} - {customer.phone}
                    </option>
                  ))}
                </select>
                {customers.length === 0 && (
                  <p className="text-sm text-amber-600 mt-2">
                    No customers found.{' '}
                    <button
                      type="button"
                      onClick={() => {
                        setShowAddModal(false);
                        onNavigate('customers');
                      }}
                      className="underline"
                    >
                      Add a customer first
                    </button>
                  </p>
                )}
              </div>

              {/* Suit Details */}
              <div className="grid sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-text-primary mb-1.5">
                    Suit Type *
                  </label>
                  <input
                    type="text"
                    value={formData.suitType}
                    onChange={(e) => setFormData({ ...formData, suitType: e.target.value })}
                    placeholder="e.g., Wedding Suit, Blazer"
                    className="w-full px-4 py-3 rounded-xl bg-white/80 border border-slate focus:border-pink focus:ring-2 focus:ring-pink/20 outline-none transition-all"
                    required
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-text-primary mb-1.5">
                    Delivery Date *
                  </label>
                  <input
                    type="date"
                    value={formData.deliveryDate}
                    onChange={(e) => setFormData({ ...formData, deliveryDate: e.target.value })}
                    className="w-full px-4 py-3 rounded-xl bg-white/80 border border-slate focus:border-pink focus:ring-2 focus:ring-pink/20 outline-none transition-all"
                    required
                  />
                </div>
              </div>

              {/* Sample Image */}
              <div>
                <label className="block text-sm font-medium text-text-primary mb-2">
                  Sample Image
                </label>
                <div className="flex items-center gap-4">
                  <div className="w-24 h-24 rounded-xl bg-slate flex items-center justify-center overflow-hidden">
                    {imagePreview ? (
                      <img
                        src={imagePreview}
                        alt="Preview"
                        className="w-full h-full object-cover"
                      />
                    ) : (
                      <Camera className="w-8 h-8 text-text-secondary" />
                    )}
                  </div>
                  <div>
                    <input
                      ref={fileInputRef}
                      type="file"
                      accept="image/*"
                      onChange={handleImageSelect}
                      className="hidden"
                    />
                    <button
                      type="button"
                      onClick={() => fileInputRef.current?.click()}
                      className="btn-secondary text-sm"
                    >
                      {imagePreview ? 'Change Image' : 'Upload Sample'}
                    </button>
                    {uploading && (
                      <p className="text-sm text-text-secondary mt-2">
                        Uploading... {progress}%
                      </p>
                    )}
                  </div>
                </div>
              </div>

              {/* Suit Details Text */}
              <div>
                <label className="block text-sm font-medium text-text-primary mb-1.5">
                  Details
                </label>
                <textarea
                  value={formData.suitDetails}
                  onChange={(e) => setFormData({ ...formData, suitDetails: e.target.value })}
                  placeholder="Fabric, color, style details..."
                  rows={2}
                  className="w-full px-4 py-3 rounded-xl bg-white/80 border border-slate focus:border-pink focus:ring-2 focus:ring-pink/20 outline-none transition-all resize-none"
                />
              </div>

              {/* Amount */}
              <div className="grid sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-text-primary mb-1.5">
                    Total Amount (₹)
                  </label>
                  <input
                    type="number"
                    value={formData.totalAmount}
                    onChange={(e) => setFormData({ ...formData, totalAmount: parseFloat(e.target.value) || 0 })}
                    placeholder="0"
                    className="w-full px-4 py-3 rounded-xl bg-white/80 border border-slate focus:border-pink focus:ring-2 focus:ring-pink/20 outline-none transition-all"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-text-primary mb-1.5">
                    Paid Amount (₹)
                  </label>
                  <input
                    type="number"
                    value={formData.paidAmount}
                    onChange={(e) => setFormData({ ...formData, paidAmount: parseFloat(e.target.value) || 0 })}
                    placeholder="0"
                    className="w-full px-4 py-3 rounded-xl bg-white/80 border border-slate focus:border-pink focus:ring-2 focus:ring-pink/20 outline-none transition-all"
                  />
                </div>
              </div>

              {/* Status */}
              <div className="grid sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-text-primary mb-1.5">
                    Order Status
                  </label>
                  <select
                    value={formData.status}
                    onChange={(e) => setFormData({ ...formData, status: e.target.value as Order['status'] })}
                    className="w-full px-4 py-3 rounded-xl bg-white/80 border border-slate focus:border-pink focus:ring-2 focus:ring-pink/20 outline-none transition-all"
                  >
                    {orderStatuses.map(s => (
                      <option key={s.value} value={s.value}>{s.label}</option>
                    ))}
                  </select>
                </div>
                <div>
                  <label className="block text-sm font-medium text-text-primary mb-1.5">
                    Payment Status
                  </label>
                  <select
                    value={formData.paymentStatus}
                    onChange={(e) => setFormData({ ...formData, paymentStatus: e.target.value as Order['paymentStatus'] })}
                    className="w-full px-4 py-3 rounded-xl bg-white/80 border border-slate focus:border-pink focus:ring-2 focus:ring-pink/20 outline-none transition-all"
                  >
                    {paymentStatuses.map(s => (
                      <option key={s.value} value={s.value}>{s.label}</option>
                    ))}
                  </select>
                </div>
              </div>

              {/* Notes */}
              <div>
                <label className="block text-sm font-medium text-text-primary mb-1.5">
                  Notes
                </label>
                <textarea
                  value={formData.notes}
                  onChange={(e) => setFormData({ ...formData, notes: e.target.value })}
                  placeholder="Any additional notes..."
                  rows={2}
                  className="w-full px-4 py-3 rounded-xl bg-white/80 border border-slate focus:border-pink focus:ring-2 focus:ring-pink/20 outline-none transition-all resize-none"
                />
              </div>

              {/* Submit */}
              <div className="sticky bottom-0 bg-white/90 backdrop-blur-xl border-t border-slate pt-4 flex gap-3">
                <button
                  type="button"
                  onClick={() => {
                    setShowAddModal(false);
                    resetForm();
                  }}
                  className="flex-1 btn-secondary"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={submitting || !formData.customerId}
                  className="flex-1 btn-primary flex items-center justify-center gap-2"
                >
                  {submitting && <Loader2 className="w-5 h-5 animate-spin" />}
                  {editingOrder ? 'Update Order' : 'Create Order'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
