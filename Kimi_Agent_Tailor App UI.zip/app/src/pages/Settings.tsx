import { useState, useRef } from 'react';
import { useAuth } from '@/contexts/AuthContext';
import { useStorage } from '@/hooks/useStorage';
import { doc, updateDoc } from 'firebase/firestore';
import { db } from '@/firebase/config';
import {
  Store,
  Camera,
  User,
  Phone,
  MapPin,
  Mail,
  Save,
  Loader2,
  CheckCircle2,
  LogOut
} from 'lucide-react';

export default function Settings() {
  const { user, shop, logout, refreshShop } = useAuth();
  const { uploadImage } = useStorage();
  const fileInputRef = useRef<HTMLInputElement>(null);

  const [formData, setFormData] = useState({
    name: shop?.name || '',
    phone: shop?.phone || '',
    address: shop?.address || '',
    email: shop?.email || ''
  });
  const [logoPreview, setLogoPreview] = useState(shop?.logo || '');
  const [logoFile, setLogoFile] = useState<File | null>(null);
  const [saving, setSaving] = useState(false);
  const [saved, setSaved] = useState(false);
  const [error, setError] = useState('');

  const handleLogoSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      setLogoFile(file);
      const reader = new FileReader();
      reader.onloadend = () => setLogoPreview(reader.result as string);
      reader.readAsDataURL(file);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user) return;

    setSaving(true);
    setError('');
    setSaved(false);

    try {
      let logoUrl = shop?.logo || '';
      
      if (logoFile) {
        logoUrl = await uploadImage(logoFile, 'logos', user.uid);
      }

      const shopRef = doc(db, 'shops', user.uid);
      await updateDoc(shopRef, {
        name: formData.name,
        phone: formData.phone,
        address: formData.address,
        email: formData.email,
        logo: logoUrl,
        updatedAt: new Date()
      });

      await refreshShop();
      setSaved(true);
      setTimeout(() => setSaved(false), 3000);
    } catch (err: any) {
      setError(err.message || 'Failed to save settings');
    } finally {
      setSaving(false);
    }
  };

  const handleLogout = async () => {
    if (confirm('Are you sure you want to logout?')) {
      await logout();
    }
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div>
        <h1 className="font-heading font-bold text-2xl lg:text-3xl text-text-primary">
          Settings
        </h1>
        <p className="text-text-secondary mt-1">
          Manage your shop profile and preferences
        </p>
      </div>

      {/* Success/Error Messages */}
      {saved && (
        <div className="p-4 rounded-xl bg-green-50 border border-green-200 flex items-center gap-3">
          <CheckCircle2 className="w-5 h-5 text-green-600" />
          <p className="text-green-600">Settings saved successfully!</p>
        </div>
      )}
      {error && (
        <div className="p-4 rounded-xl bg-red-50 border border-red-200 text-red-600">
          {error}
        </div>
      )}

      <form onSubmit={handleSubmit} className="space-y-6">
        {/* Logo Section */}
        <div className="glass-card p-6">
          <h2 className="font-heading font-semibold text-lg text-text-primary mb-4 flex items-center gap-2">
            <Store className="w-5 h-5 text-pink" />
            Shop Logo
          </h2>
          <div className="flex items-center gap-6">
            <div className="w-24 h-24 rounded-2xl bg-slate flex items-center justify-center overflow-hidden">
              {logoPreview ? (
                <img
                  src={logoPreview}
                  alt="Shop Logo"
                  className="w-full h-full object-cover"
                />
              ) : (
                <Store className="w-10 h-10 text-text-secondary" />
              )}
            </div>
            <div>
              <input
                ref={fileInputRef}
                type="file"
                accept="image/*"
                onChange={handleLogoSelect}
                className="hidden"
              />
              <button
                type="button"
                onClick={() => fileInputRef.current?.click()}
                className="btn-secondary flex items-center gap-2"
              >
                <Camera className="w-4 h-4" />
                {logoPreview ? 'Change Logo' : 'Upload Logo'}
              </button>
              <p className="text-sm text-text-secondary mt-2">
                Recommended: Square image, at least 200x200px
              </p>
            </div>
          </div>
        </div>

        {/* Shop Details */}
        <div className="glass-card p-6">
          <h2 className="font-heading font-semibold text-lg text-text-primary mb-4 flex items-center gap-2">
            <User className="w-5 h-5 text-pink" />
            Shop Details
          </h2>
          <div className="grid sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-text-primary mb-1.5">
                Shop Name *
              </label>
              <input
                type="text"
                value={formData.name}
                onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                placeholder="Your shop name"
                className="w-full px-4 py-3 rounded-xl bg-white/80 border border-slate focus:border-pink focus:ring-2 focus:ring-pink/20 outline-none transition-all"
                required
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-text-primary mb-1.5">
                Phone Number
              </label>
              <div className="relative">
                <Phone className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-text-secondary" />
                <input
                  type="tel"
                  value={formData.phone}
                  onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                  placeholder="Your phone number"
                  className="w-full pl-12 pr-4 py-3 rounded-xl bg-white/80 border border-slate focus:border-pink focus:ring-2 focus:ring-pink/20 outline-none transition-all"
                />
              </div>
            </div>
            <div>
              <label className="block text-sm font-medium text-text-primary mb-1.5">
                Email
              </label>
              <div className="relative">
                <Mail className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-text-secondary" />
                <input
                  type="email"
                  value={formData.email}
                  onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                  placeholder="Your email address"
                  className="w-full pl-12 pr-4 py-3 rounded-xl bg-white/80 border border-slate focus:border-pink focus:ring-2 focus:ring-pink/20 outline-none transition-all"
                />
              </div>
            </div>
            <div className="sm:col-span-2">
              <label className="block text-sm font-medium text-text-primary mb-1.5">
                Address
              </label>
              <div className="relative">
                <MapPin className="absolute left-4 top-4 w-5 h-5 text-text-secondary" />
                <textarea
                  value={formData.address}
                  onChange={(e) => setFormData({ ...formData, address: e.target.value })}
                  placeholder="Your shop address"
                  rows={3}
                  className="w-full pl-12 pr-4 py-3 rounded-xl bg-white/80 border border-slate focus:border-pink focus:ring-2 focus:ring-pink/20 outline-none transition-all resize-none"
                />
              </div>
            </div>
          </div>
        </div>

        {/* Save Button */}
        <div className="flex flex-col sm:flex-row gap-4">
          <button
            type="submit"
            disabled={saving}
            className="flex-1 btn-primary flex items-center justify-center gap-2 py-4"
          >
            {saving ? (
              <>
                <Loader2 className="w-5 h-5 animate-spin" />
                Saving...
              </>
            ) : (
              <>
                <Save className="w-5 h-5" />
                Save Changes
              </>
            )}
          </button>
        </div>
      </form>

      {/* Logout Section */}
      <div className="glass-card p-6 border-red-200">
        <h2 className="font-heading font-semibold text-lg text-red-600 mb-4 flex items-center gap-2">
          <LogOut className="w-5 h-5" />
          Account
        </h2>
        <p className="text-text-secondary mb-4">
          Sign out of your account. You will need to login again to access your dashboard.
        </p>
        <button
          onClick={handleLogout}
          className="px-6 py-3 rounded-full bg-red-50 text-red-600 font-medium hover:bg-red-100 transition-colors flex items-center gap-2"
        >
          <LogOut className="w-5 h-5" />
          Logout
        </button>
      </div>

      {/* Account Info */}
      <div className="glass-card p-6">
        <h2 className="font-heading font-semibold text-lg text-text-primary mb-4">
          Account Information
        </h2>
        <div className="space-y-3 text-sm">
          <div className="flex justify-between">
            <span className="text-text-secondary">Account ID</span>
            <span className="text-text-primary font-mono">{user?.uid?.slice(0, 8)}...</span>
          </div>
          <div className="flex justify-between">
            <span className="text-text-secondary">Email</span>
            <span className="text-text-primary">{user?.email}</span>
          </div>
          <div className="flex justify-between">
            <span className="text-text-secondary">Account Created</span>
            <span className="text-text-primary">
              {user?.metadata?.creationTime 
                ? new Date(user.metadata.creationTime).toLocaleDateString() 
                : 'N/A'}
            </span>
          </div>
        </div>
      </div>
    </div>
  );
}
