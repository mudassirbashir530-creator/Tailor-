import { useState, useRef } from 'react';
import { useAuth } from '@/contexts/AuthContext';
import { useOrders } from '@/hooks/useFirestore';
import {
  FileText,
  Search,
  Download,
  Printer,
  X,
  IndianRupee,
  Calendar,
  CheckCircle2,
  Loader2,
  Receipt
} from 'lucide-react';
import type { Order } from '@/types';

interface InvoicesProps {
  onNavigate: (page: string) => void;
}

export default function Invoices({ onNavigate }: InvoicesProps) {
  const { user, shop } = useAuth();
  const { orders, loading } = useOrders(user?.uid);
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedOrder, setSelectedOrder] = useState<Order | null>(null);
  const invoiceRef = useRef<HTMLDivElement>(null);

  // Filter only paid orders with invoices
  const invoiceOrders = orders.filter(order => 
    order.paymentStatus === 'paid'
  );

  const filteredOrders = invoiceOrders.filter(order =>
    order.customerName.toLowerCase().includes(searchQuery.toLowerCase()) ||
    order.suitType.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const generateInvoiceNumber = (order: Order) => {
    const date = order.createdAt.toISOString().slice(0, 10).replace(/-/g, '');
    return `INV-${date}-${order.id.slice(-4).toUpperCase()}`;
  };

  const handlePrint = () => {
    if (invoiceRef.current) {
      const printWindow = window.open('', '_blank');
      if (printWindow) {
        printWindow.document.write(`
          <html>
            <head>
              <title>Invoice - ${selectedOrder?.customerName}</title>
              <style>
                body { font-family: Arial, sans-serif; padding: 40px; max-width: 800px; margin: 0 auto; }
                .header { text-align: center; margin-bottom: 30px; }
                .logo { width: 80px; height: 80px; border-radius: 50%; background: #F2A0B5; display: flex; align-items: center; justify-content: center; margin: 0 auto 15px; }
                .invoice-title { font-size: 24px; font-weight: bold; color: #1B1F2A; }
                .details { display: flex; justify-content: space-between; margin-bottom: 30px; }
                .section { margin-bottom: 20px; }
                .section-title { font-weight: bold; margin-bottom: 10px; color: #6B7280; }
                table { width: 100%; border-collapse: collapse; margin: 20px 0; }
                th, td { padding: 12px; text-align: left; border-bottom: 1px solid #E9EDF3; }
                th { background: #F6F7F9; font-weight: 600; }
                .total-row { font-weight: bold; background: #F6F7F9; }
                .footer { margin-top: 40px; text-align: center; color: #6B7280; font-size: 14px; }
                @media print { body { padding: 20px; } }
              </style>
            </head>
            <body>
              ${invoiceRef.current.innerHTML}
            </body>
          </html>
        `);
        printWindow.document.close();
        printWindow.print();
      }
    }
  };

  const handleDownload = () => {
    if (invoiceRef.current) {
      const htmlContent = `
        <html>
          <head>
            <title>Invoice - ${selectedOrder?.customerName}</title>
            <style>
              body { font-family: Arial, sans-serif; padding: 40px; max-width: 800px; margin: 0 auto; }
              .header { text-align: center; margin-bottom: 30px; }
              .logo { width: 80px; height: 80px; border-radius: 50%; background: #F2A0B5; display: flex; align-items: center; justify-content: center; margin: 0 auto 15px; }
              .invoice-title { font-size: 24px; font-weight: bold; color: #1B1F2A; }
              .details { display: flex; justify-content: space-between; margin-bottom: 30px; }
              .section { margin-bottom: 20px; }
              .section-title { font-weight: bold; margin-bottom: 10px; color: #6B7280; }
              table { width: 100%; border-collapse: collapse; margin: 20px 0; }
              th, td { padding: 12px; text-align: left; border-bottom: 1px solid #E9EDF3; }
              th { background: #F6F7F9; font-weight: 600; }
              .total-row { font-weight: bold; background: #F6F7F9; }
              .footer { margin-top: 40px; text-align: center; color: #6B7280; font-size: 14px; }
            </style>
          </head>
          <body>
            ${invoiceRef.current.innerHTML}
          </body>
        </html>
      `;
      
      const blob = new Blob([htmlContent], { type: 'text/html' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `Invoice-${selectedOrder?.customerName}-${generateInvoiceNumber(selectedOrder!)}.html`;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);
    }
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div>
        <h1 className="font-heading font-bold text-2xl lg:text-3xl text-text-primary">
          Invoices
        </h1>
        <p className="text-text-secondary mt-1">
          View and download customer invoices
        </p>
      </div>

      {/* Search */}
      <div className="relative">
        <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-text-secondary" />
        <input
          type="text"
          placeholder="Search invoices by customer or order..."
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          className="w-full pl-12 pr-4 py-3 rounded-xl bg-white/80 border border-slate focus:border-pink focus:ring-2 focus:ring-pink/20 outline-none transition-all"
        />
      </div>

      {/* Invoices List */}
      {loading ? (
        <div className="flex justify-center py-12">
          <Loader2 className="w-8 h-8 animate-spin text-pink" />
        </div>
      ) : filteredOrders.length === 0 ? (
        <div className="glass-card p-12 text-center">
          <Receipt className="w-16 h-16 mx-auto mb-4 text-text-secondary opacity-30" />
          <h3 className="font-heading font-semibold text-lg text-text-primary mb-2">
            No invoices yet
          </h3>
          <p className="text-text-secondary mb-4">
            Invoices are automatically created when orders are marked as paid
          </p>
          <button
            onClick={() => onNavigate('orders')}
            className="btn-primary"
          >
            Go to Orders
          </button>
        </div>
      ) : (
        <div className="grid gap-3">
          {filteredOrders.map((order) => (
            <div key={order.id} className="glass-card p-4">
              <div className="flex flex-col sm:flex-row sm:items-center gap-4">
                <div className="w-12 h-12 rounded-xl bg-green-100 flex items-center justify-center flex-shrink-0">
                  <FileText className="w-6 h-6 text-green-600" />
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex flex-wrap items-center gap-2 mb-1">
                    <h3 className="font-medium text-text-primary">{order.customerName}</h3>
                    <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-medium bg-green-100 text-green-600">
                      <CheckCircle2 className="w-3.5 h-3.5" />
                      Paid
                    </span>
                  </div>
                  <p className="text-sm text-text-secondary">{order.suitType}</p>
                  <div className="flex flex-wrap items-center gap-3 mt-2 text-xs text-text-secondary">
                    <span className="flex items-center gap-1">
                      <Receipt className="w-3.5 h-3.5" />
                      {generateInvoiceNumber(order)}
                    </span>
                    <span className="flex items-center gap-1">
                      <Calendar className="w-3.5 h-3.5" />
                      {order.createdAt.toLocaleDateString()}
                    </span>
                    <span className="flex items-center gap-1">
                      <IndianRupee className="w-3.5 h-3.5" />
                      ₹{order.totalAmount.toLocaleString()}
                    </span>
                  </div>
                </div>
                <button
                  onClick={() => setSelectedOrder(order)}
                  className="btn-secondary text-sm flex items-center gap-2"
                >
                  <FileText className="w-4 h-4" />
                  View Invoice
                </button>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Invoice Modal */}
      {selectedOrder && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50 backdrop-blur-sm">
          <div className="glass-card w-full max-w-3xl max-h-[90vh] overflow-auto">
            {/* Modal Header */}
            <div className="sticky top-0 bg-white/90 backdrop-blur-xl border-b border-slate p-4 flex items-center justify-between">
              <h2 className="font-heading font-semibold text-xl text-text-primary">
                Invoice
              </h2>
              <div className="flex items-center gap-2">
                <button
                  onClick={handlePrint}
                  className="w-10 h-10 rounded-xl bg-slate hover:bg-slate/80 flex items-center justify-center"
                  title="Print"
                >
                  <Printer className="w-5 h-5" />
                </button>
                <button
                  onClick={handleDownload}
                  className="w-10 h-10 rounded-xl bg-slate hover:bg-slate/80 flex items-center justify-center"
                  title="Download"
                >
                  <Download className="w-5 h-5" />
                </button>
                <button
                  onClick={() => setSelectedOrder(null)}
                  className="w-10 h-10 rounded-xl hover:bg-slate flex items-center justify-center"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>
            </div>

            {/* Invoice Content */}
            <div className="p-8">
              <div ref={invoiceRef}>
                {/* Invoice Header */}
                <div className="text-center mb-8">
                  {shop?.logo ? (
                    <img
                      src={shop.logo}
                      alt={shop.name}
                      className="w-20 h-20 rounded-full mx-auto mb-4 object-cover"
                    />
                  ) : (
                    <div className="w-20 h-20 rounded-full bg-pink mx-auto mb-4 flex items-center justify-center">
                      <span className="text-white text-2xl font-bold">
                        {shop?.name?.charAt(0) || 'T'}
                      </span>
                    </div>
                  )}
                  <h1 className="text-2xl font-bold text-text-primary">{shop?.name || 'Your Shop'}</h1>
                  <p className="text-text-secondary mt-1">{shop?.address}</p>
                  <p className="text-text-secondary">{shop?.phone}</p>
                  <p className="text-text-secondary">{shop?.email}</p>
                </div>

                <hr className="border-slate mb-6" />

                {/* Invoice Details */}
                <div className="flex flex-col sm:flex-row justify-between gap-6 mb-6">
                  <div>
                    <p className="text-sm text-text-secondary mb-1">Bill To:</p>
                    <p className="font-semibold text-text-primary">{selectedOrder.customerName}</p>
                  </div>
                  <div className="text-left sm:text-right">
                    <p className="text-sm text-text-secondary mb-1">Invoice Number:</p>
                    <p className="font-semibold text-text-primary">{generateInvoiceNumber(selectedOrder)}</p>
                    <p className="text-sm text-text-secondary mt-2 mb-1">Date:</p>
                    <p className="font-semibold text-text-primary">{selectedOrder.createdAt.toLocaleDateString()}</p>
                  </div>
                </div>

                {/* Items Table */}
                <table className="w-full mb-6">
                  <thead>
                    <tr className="bg-slate/50">
                      <th className="text-left p-3 rounded-tl-lg">Description</th>
                      <th className="text-center p-3">Qty</th>
                      <th className="text-right p-3">Rate</th>
                      <th className="text-right p-3 rounded-tr-lg">Amount</th>
                    </tr>
                  </thead>
                  <tbody>
                    <tr className="border-b border-slate">
                      <td className="p-3">
                        <p className="font-medium text-text-primary">{selectedOrder.suitType}</p>
                        <p className="text-sm text-text-secondary">{selectedOrder.suitDetails}</p>
                      </td>
                      <td className="text-center p-3">1</td>
                      <td className="text-right p-3">₹{selectedOrder.totalAmount.toLocaleString()}</td>
                      <td className="text-right p-3">₹{selectedOrder.totalAmount.toLocaleString()}</td>
                    </tr>
                  </tbody>
                  <tfoot>
                    <tr className="bg-slate/30 font-semibold">
                      <td colSpan={3} className="text-right p-3 rounded-bl-lg">Total:</td>
                      <td className="text-right p-3 rounded-br-lg">₹{selectedOrder.totalAmount.toLocaleString()}</td>
                    </tr>
                    <tr>
                      <td colSpan={3} className="text-right p-3 text-green-600">Amount Paid:</td>
                      <td className="text-right p-3 text-green-600">₹{selectedOrder.paidAmount.toLocaleString()}</td>
                    </tr>
                    {selectedOrder.totalAmount - selectedOrder.paidAmount > 0 && (
                      <tr>
                        <td colSpan={3} className="text-right p-3 text-amber-600">Balance:</td>
                        <td className="text-right p-3 text-amber-600">₹{(selectedOrder.totalAmount - selectedOrder.paidAmount).toLocaleString()}</td>
                      </tr>
                    )}
                  </tfoot>
                </table>

                {/* Payment Status */}
                <div className="flex items-center justify-center gap-2 p-4 bg-green-50 rounded-xl mb-6">
                  <CheckCircle2 className="w-5 h-5 text-green-600" />
                  <span className="font-semibold text-green-600">Payment Received - Thank You!</span>
                </div>

                {/* Footer */}
                <div className="text-center text-text-secondary text-sm">
                  <p>Thank you for your business!</p>
                  <p className="mt-1">This is a computer-generated invoice.</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
